Configuration ContosoWebsite
{

Import-DscResource -ModuleName PSDesiredStateConfiguration

Node $nodeName
  {
    WindowsFeature WebServerRole
    {
      Name = "Web-Server"
      Ensure = "Present"
    }
    WindowsFeature WebManagementConsole
    {
      Name = "Web-Mgmt-Console"
      Ensure = "Present"
    }
    WindowsFeature WebManagementService
    {
      Name = "Web-Mgmt-Service"
      Ensure = "Present"
    }
    WindowsFeature ASPNet45
    {
      Name = "Web-Asp-Net45"
      Ensure = "Present"
    }
    WindowsFeature HTTPRedirection
    {
      Name = "Web-Http-Redirect"
      Ensure = "Present"
    }
    Package UrlRewrite
    {
        Ensure = "Present"
        Name = "IIS URL Rewrite Module 2"
        Path = "https://download.microsoft.com/download/C/9/E/C9E8180D-4E51-40A6-A9BF-776990D8BCA9/rewrite_amd64.msi"
        ProductId = "08F0318A-D113-4CF0-993E-50F191D397AD"
        DependsOn = "[WindowsFeature]WebServerRole"
    }
   
    Script Binding
		{
			GetScript = {@{Result = "Binding"}}
			TestScript = {$false}
			SetScript ={
				New-WebBinding -Name "Default Web Site" -IP "*" -Port 8080 -Protocol http					
			}
		}
 foreach ($fwProfile in 'Domain', 'Public')
         {
             xFirewall "Firewall-$fwProfile"
             {
                 Name                  = "TailpinToys Dev-$fwProfile"
                 DisplayName           = "Firewall Rule for TailpinToys Dev (Profile: $fwProfile)"
                 DisplayGroup          = "Tailspin"
                 Ensure                = "Present"
                 Access                = "Allow"
                 State                 = "Enabled"
                 Profile               = $fwProfile
                 Direction             = "InBound"
                 RemotePort            = ("8080")
                 LocalPort             = ("8080")         
                 Protocol              = "TCP"
                 Description           = "Firewall Rule for NTailpinToys Dev (Profile: $fwProfile)"  
 
             }
         }
  }
}