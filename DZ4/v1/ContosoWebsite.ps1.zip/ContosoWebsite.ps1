Configuration ContosoWebsite
{
  param ($MachineName)
  Import-DSCResource -Module xNetworking
	 
  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }

	xWebsite DefaultSite
	{
 	  Ensure = "Present"
  	  Name = "Default Web Site"
  	  PhysicalPath = "C:\inetpub\wwwroot"
  	  State = "Started"
	  BindingInfo     = @( MSFT_xWebBindingInformation
                                {
                                   Protocol = "HTTP" 
									Port = 80
									IPAddress = '*'
								}
                                 MSFT_xWebBindingInformation
                                {
                                   Protocol = "HTTP" 
									Port = 8080
									IPAddress = '*'
								}
                             )
   	 DependsOn = "[WindowsFeature]IIS"
	}
	
foreach ($fwProfile in 'Domain', 'Public')
         {
             xFirewall "Firewall-$fwProfile"
             {
                 Name                  = "8080 $fwProfile"
                 DisplayName           = "Firewall Rule for 8080 (Profile: $fwProfile)"
                 DisplayGroup          = "8080"
                 Ensure                = "Present"
                 Access                = "Allow"
                 State                 = "Enabled"
                 Profile               = $fwProfile
                 Direction             = "InBound"
                 RemotePort            = ("8080")
                 LocalPort             = ("8080")         
                 Protocol              = "TCP"
                 Description           = "Firewall Rule for NTailpinToys Dev (Profile: $fwProfile)"  
                 }
         }
  }
 }
 