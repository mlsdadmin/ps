Configuration ContosoWebsite
{
  param ($MachineName)

  Node $MachineName
  {
    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = �Present�
      Name = �Web-Server�
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = �Present�
      Name = �Web-Asp-Net45�
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
	#Website Creation
	dsc_xwebsite{'dev.example.com':
	dsc_ensure => 'Present',
	dsc_name => 'dev.example.com',
	dsc_state => 'Started',
	dsc_physicalpath => 'C:\\www\\dev.example.com\\webroot',
	dsc_applicationpool => 'dev.example.com',
	dsc_bindinginfo => [{
	ipaddress => '*',
    protocol => 'HTTP',
    port => 8080,
    hostname => 'dev.example.com',
    }],
 require => Dsc_xwebapppool['dev.example.com'],
  }
  }
} 